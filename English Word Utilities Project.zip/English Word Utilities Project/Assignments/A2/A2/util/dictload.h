#ifndef __WORDUTILSLIB_DICTLOAD_H__
#define __WORDUTILSLIB_DICTLOAD_H__
#include <dicttype.h>
dict loaddfltdict();
dict loaddict(const char *fname);
#endif