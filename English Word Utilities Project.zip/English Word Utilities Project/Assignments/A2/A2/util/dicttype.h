#ifndef __WORDUTILSLIB_DICTTYPE_H__
#define __WORDUTILSLIB_DICTTYPE_H__
#include <trie.h>
typedef trie dict;
#endif
