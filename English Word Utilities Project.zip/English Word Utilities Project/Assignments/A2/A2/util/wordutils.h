#ifndef __WORDUTILSLIB_WORDUTILS_H
#define __WORDUTILSLIB_WORDUTILS_H

#include <dictload.h>
#include <dictutils.h>

#endif
